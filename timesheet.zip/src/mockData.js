// src/mockData.js
export const availableRides = [
  {
    id: "R123",
    from: "Kondapur",
    to: "Gachibowli",
    price: 120,
    driver: "Ramesh",
  },
  {
    id: "R456",
    from: "Hitech City",
    to: "Jubilee Hills",
    price: 180,
    driver: "Suresh",
  },
  {
    id: "R789",
    from: "Banjara Hills",
    to: "Secunderabad",
    price: 250,
    driver: "Anitha",
  },
];
