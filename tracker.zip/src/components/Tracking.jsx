import * as maptilersdk from "@maptiler/sdk";
import "@maptiler/sdk/dist/maptiler-sdk.css";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

import React, { useState, useEffect, useRef, useCallback } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  Container,
  Row,
  Col,
  Card,
  Badge,
  ListGroup,
  Spinner,
  Button,
  ToastContainer,
  Toast,
} from "react-bootstrap";
import {
  ArrowRepeat,
  ShareFill,
  CheckCircleFill,
  Download,
  Layers,
  GeoAltFill,
} from "react-bootstrap-icons";
// Import the updated CSS
import "./Tracking.css";

// (Your API Keys and Helper Functions here - no changes needed)
// ...
const MAPTILER_API_KEY = "IM5fa8LxttCOF3H4Sxqa"; // Your MapTiler API Key
const GEOAPIFY_API_KEY = "03a175bc0c42441180e543cad39c5749"; // Your Geoapify API Key

// Constants
const SIMULATION_STEP_MS = 100;
const GEOCODING_INTERVAL_STEPS = 50;
const REQUEST_TIMEOUT = 10000;

// --- Helper Functions (No changes needed here) ---
const fetchWithRetry = async (
  url,
  options = {},
  retries = 3,
  backoff = 2000
) => {
  for (let i = 0; i < retries; i++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT);
      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
      });
      clearTimeout(timeoutId);
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);
      return await response.json();
    } catch (error) {
      console.warn(
        `Attempt ${i + 1} failed. Retrying in ${backoff / 1000}s...`
      );
      if (i === retries - 1) throw error;
      await new Promise((res) => setTimeout(res, backoff));
      backoff *= 2;
    }
  }
};

const getPlacename = async (lat, lng) => {
  const url = `https://api.geoapify.com/v1/geocode/reverse?lat=${lat}&lon=${lng}&apiKey=${GEOAPIFY_API_KEY}`;
  try {
    const data = await fetchWithRetry(url);
    return data?.features?.[0]?.properties?.formatted || "Unknown Location";
  } catch (error) {
    console.error("Final error fetching placename:", error.name);
    return "API Request Failed";
  }
};

const Tracking = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const { ride } = state || {};

  // (All your existing refs and state variables - no changes needed)
  // ...
  const mapContainer = useRef(null);
  const map = useRef(null);
  const driverMarker = useRef(null);
  const routeGeoJSON = useRef(null);

  // State
  const [route, setRoute] = useState([]);
  const [initialDistance, setInitialDistance] = useState(0);
  const [initialEta, setInitialEta] = useState(0);
  const [remainingDistance, setRemainingDistance] = useState("");
  const [remainingEta, setRemainingEta] = useState("");
  const [isTripOver, setIsTripOver] = useState(false);
  const [liveTimeSheet, setLiveTimeSheet] = useState([]);
  const [currentPlacename, setCurrentPlacename] = useState(
    "Determining location..."
  );
  const [statusMessage, setStatusMessage] = useState("Journey Initiated");
  const [showToast, setShowToast] = useState(false);
  const [currentMapStyle, setCurrentMapStyle] = useState(
    maptilersdk.MapStyle.STREETS
  );
  const stepRef = useRef(0);
  const intervalRef = useRef(null);

  // (All your existing useEffect hooks - they are perfectly structured, no changes needed)
  // ...
  useEffect(() => {
    if (map.current || !mapContainer.current) return; // Exit if map is already initialized
    maptilersdk.config.apiKey = MAPTILER_API_KEY;
    const center = ride
      ? [ride.driverStartLocation.lng, ride.driverStartLocation.lat]
      : [0, 0];
    map.current = new maptilersdk.Map({
      container: mapContainer.current,
      style: maptilersdk.MapStyle.STREETS,
      center: center,
      zoom: 14,
    });
    map.current.addControl(new maptilersdk.NavigationControl(), "top-right");
    return () => {
      map.current?.remove();
      map.current = null;
    };
  }, [ride]);

  useEffect(() => {
    if (!map.current) return;
    const addLayers = () => {
      if (!map.current.getSource("maptiler-traffic")) {
        map.current.addSource("maptiler-traffic", {
          type: "vector",
          url: `https://api.maptiler.com/tiles/traffic/tiles.json?key=${MAPTILER_API_KEY}`,
        });
        map.current.addLayer({
          id: "traffic-flow",
          type: "line",
          source: "maptiler-traffic",
          "source-layer": "traffic",
          paint: {
            "line-width": 2,
            "line-color": [
              "match",
              ["get", "congestion"],
              "low",
              "#32CD32", // green
              "moderate",
              "#FFA500", // orange
              "heavy",
              "#FF4500", // red
              "severe",
              "#8B0000", // dark red
              "#32CD32", // default
            ],
          },
        });
      }
      if (routeGeoJSON.current && !map.current.getSource("route")) {
        map.current.addSource("route", {
          type: "geojson",
          data: routeGeoJSON.current,
        });
        map.current.addLayer({
          id: "route",
          type: "line",
          source: "route",
          paint: { "line-color": "#0d6efd", "line-width": 6 },
        });
      }
    };
    const onStyleLoad = () => addLayers();
    map.current.on("style.load", onStyleLoad);
    map.current.setStyle(currentMapStyle);
    return () => {
      if (map.current) {
        map.current.off("style.load", onStyleLoad);
      }
    };
  }, [currentMapStyle]);

  useEffect(() => {
    if (!ride || !map.current) return;
    new maptilersdk.Marker({ color: "#FF0000" })
      .setLngLat([ride.userLocation.lng, ride.userLocation.lat])
      .setPopup(new maptilersdk.Popup().setText("Destination"))
      .addTo(map.current);
    driverMarker.current = new maptilersdk.Marker({ color: "#007bff" })
      .setLngLat([ride.driverStartLocation.lng, ride.driverStartLocation.lat])
      .setPopup(new maptilersdk.Popup().setText("Live Location"))
      .addTo(map.current);
    const fetchRouteAndSetupMap = async () => {
      setCurrentPlacename(ride.from);
      try {
        const routeUrl = `https://router.project-osrm.org/route/v1/driving/${ride.driverStartLocation.lng},${ride.driverStartLocation.lat};${ride.userLocation.lng},${ride.userLocation.lat}?overview=full&geometries=geojson`;
        const data = await fetchWithRetry(routeUrl);
        if (data?.code === "Ok" && data.routes?.[0]) {
          const routeData = data.routes[0];
          routeGeoJSON.current = routeData.geometry;
          const coordinates = routeData.geometry.coordinates;
          setRoute(coordinates.map((c) => [c[1], c[0]]));
          const distanceInKm = routeData.distance / 1000;
          const durationInMin = routeData.duration / 60;
          setInitialDistance(distanceInKm);
          setInitialEta(durationInMin);
          setRemainingDistance(`${distanceInKm.toFixed(2)} km`);
          setRemainingEta(`${Math.round(durationInMin)} minutes`);
          const setupRouteOnMap = () => {
            if (map.current.getSource("route")) {
              map.current.getSource("route").setData(routeGeoJSON.current);
            } else {
              map.current.addSource("route", {
                type: "geojson",
                data: routeGeoJSON.current,
              });
              map.current.addLayer({
                id: "route",
                type: "line",
                source: "route",
                layout: { "line-join": "round", "line-cap": "round" },
                paint: {
                  "line-color": "#0d6efd",
                  "line-width": 6,
                  "line-opacity": 0.8,
                },
              });
            }
            const bounds = coordinates.reduce(
              (bounds, coord) => bounds.extend(coord),
              new maptilersdk.LngLatBounds(coordinates[0], coordinates[0])
            );
            map.current.fitBounds(bounds, { padding: 60 });
          };
          if (map.current.isStyleLoaded()) {
            setupRouteOnMap();
          } else {
            map.current.once("load", setupRouteOnMap);
          }
        } else {
          setCurrentPlacename("Could not fetch route from OSRM.");
        }
      } catch (error) {
        console.error("Failed to fetch route:", error);
        setCurrentPlacename(`Error fetching route: ${error.message}`);
      }
    };
    fetchRouteAndSetupMap();
  }, [ride]);

  useEffect(() => {
    if (route.length === 0 || !ride || !initialEta) return;
    intervalRef.current = setInterval(() => {
      const currentStep = stepRef.current;
      if (currentStep >= route.length) {
        clearInterval(intervalRef.current);
        if (driverMarker.current) {
          driverMarker.current.setLngLat([
            ride.userLocation.lng,
            ride.userLocation.lat,
          ]);
        }
        setIsTripOver(true);
        setStatusMessage("Arrived at Destination");
        setCurrentPlacename(ride.to);
        const completedJourney = {
          ...ride,
          date: new Date().toLocaleDateString(),
          duration: `${Math.round(initialEta)} min`,
          status: "Completed",
          endTime: new Date().toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit",
          }),
          timesheet: [
            ...liveTimeSheet,
            {
              location: ride.to,
              time: new Date().toLocaleTimeString("en-US", {
                hour: "2-digit",
                minute: "2-digit",
              }),
            },
          ],
        };
        const history = JSON.parse(localStorage.getItem("rideHistory")) || [];
        localStorage.setItem(
          "rideHistory",
          JSON.stringify([...history, completedJourney])
        );
        return;
      }
      const currentPos = route[currentStep];
      const currentLngLat = [currentPos[1], currentPos[0]];
      if (driverMarker.current) driverMarker.current.setLngLat(currentLngLat);
      if (map.current) map.current.panTo(currentLngLat);
      const distanceToEnd =
        new maptilersdk.LngLat(currentLngLat[0], currentLngLat[1]).distanceTo(
          new maptilersdk.LngLat(ride.userLocation.lng, ride.userLocation.lat)
        ) / 1000;
      setRemainingDistance(`${distanceToEnd.toFixed(2)} km`);
      const speedKmM = initialDistance > 0 ? initialDistance / initialEta : 1;
      const newEta = Math.round(distanceToEnd / speedKmM);
      setRemainingEta(`${newEta} minutes`);
      if (newEta < 5 && newEta > 0) setStatusMessage("Arriving soon...");
      else if (currentStep > route.length / 2)
        setStatusMessage("More than halfway there");
      if (currentStep > 0 && currentStep % GEOCODING_INTERVAL_STEPS === 0) {
        getPlacename(currentPos[0], currentPos[1]).then((placename) => {
          setCurrentPlacename(placename);
          const currentTime = new Date().toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit",
          });
          setLiveTimeSheet((prev) => [
            ...prev,
            { location: placename, time: currentTime },
          ]);
        });
      }
      stepRef.current += 1;
    }, SIMULATION_STEP_MS);
    return () => clearInterval(intervalRef.current);
  }, [route, ride, initialDistance, initialEta, liveTimeSheet]);

  // (All your existing event handlers - no changes needed)
  // ...
  const handleRecenter = () => {
    if (map.current && driverMarker.current) {
      map.current.panTo(driverMarker.current.getLngLat(), { duration: 1000 });
    }
  };

  const handleShare = () => {
    const shareText = `I am tracking a journey from ${ride.from} to ${ride.to}. Current ETA: ${remainingEta}.`;
    navigator.clipboard.writeText(shareText);
    setShowToast(true);
  };

  const handleDownload = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text(`Journey Log - ${ride.id}`, 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);
    doc.text(`From: ${ride.from}`, 14, 30);
    doc.text(`To: ${ride.to}`, 14, 36);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 14, 42);
    const tableColumn = ["Time", "Location Reached"];
    const tableRows = [];
    const finalTimesheet = isTripOver
      ? liveTimeSheet
      : [...liveTimeSheet, { time: "In Progress", location: currentPlacename }];
    finalTimesheet.forEach((entry) => {
      tableRows.push([entry.time, entry.location]);
    });
    autoTable(doc, { head: [tableColumn], body: tableRows, startY: 50 });
    doc.save(`Journey-Log-${ride.id}.pdf`);
  };

  const handleStyleToggle = () => {
    setCurrentMapStyle((prevStyle) =>
      prevStyle === maptilersdk.MapStyle.STREETS
        ? maptilersdk.MapStyle.SATELLITE
        : maptilersdk.MapStyle.STREETS
    );
  };

  if (!ride) {
    return (
      <Container className="p-5 text-center">
        <h1>No Journey Data Found</h1>
        <p>Please set up a journey to track first.</p>
        <Button onClick={() => navigate("/")}>Setup New Journey</Button>
      </Container>
    );
  }

  // --- REFACTORED RENDER LOGIC ---
  return (
    <Container fluid className="tracking-page-container">
      <div className="tracking-header text-center">
        <h1>Tracking Journey: {ride.id}</h1>
      </div>

      <Row className="mx-lg-4">
        <Col xs={12} lg={7} className="map-col position-relative mb-4 mb-lg-0">
          <div ref={mapContainer} className="map-view" />
          <Button
            variant="light"
            className="recenter-btn shadow-sm"
            onClick={handleRecenter}
            title="Re-center on Vehicle"
          >
            <GeoAltFill size={20} />
          </Button>
          <Button
            variant="light"
            className="style-toggle-btn shadow-sm"
            onClick={handleStyleToggle}
            title="Toggle Map Style"
          >
            <Layers size={20} />
          </Button>
        </Col>
        <Col xs={12} lg={5} className="details-col">
          <Row className="h-100">
            {/* --- Top Card for Status & ETA --- */}
            <Col xs={12} className="mb-4">
              <Card className="info-card">
                <Card.Header as="h5">Live Status</Card.Header>
                <Card.Body>
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <strong>Status:</strong>
                    <Badge
                      bg={isTripOver ? "primary" : "success"}
                      pill
                      className="p-2 px-3"
                    >
                      {isTripOver ? "Arrived" : statusMessage}
                    </Badge>
                  </div>
                  <p>
                    <strong>Current Location:</strong>
                    <br />
                    {currentPlacename.includes("Failed") ? (
                      <span className="text-danger fw-bold">
                        {currentPlacename}
                      </span>
                    ) : (
                      currentPlacename || <Spinner size="sm" />
                    )}
                  </p>
                  <hr />
                  <Row>
                    <Col>
                      <p className="mb-0">
                        <strong>ETA</strong>
                      </p>
                      <p className="fs-4">{remainingEta}</p>
                    </Col>
                    <Col>
                      <p className="mb-0">
                        <strong>Distance</strong>
                      </p>
                      <p className="fs-4">{remainingDistance}</p>
                    </Col>
                  </Row>
                  <Button
                    variant="outline-primary"
                    className="w-100 mt-2"
                    onClick={handleShare}
                  >
                    <ShareFill className="me-2" /> Share Journey
                  </Button>
                </Card.Body>
              </Card>
            </Col>

            {/* --- Bottom Card for Log / Completed View --- */}
            <Col xs={12}>
              <Card className="info-card">
                {/* Card Header is now dynamic */}
                <Card.Header
                  as="h5"
                  className="d-flex justify-content-between align-items-center"
                >
                  <span>
                    {isTripOver ? "Journey Summary" : "Live Journey Log"}
                  </span>
                  <Button
                    variant="outline-secondary"
                    size="sm"
                    onClick={handleDownload}
                  >
                    <Download className="me-1" />{" "}
                    {isTripOver ? "Download" : "Log"}
                  </Button>
                </Card.Header>
                <Card.Body
                  className={
                    isTripOver
                      ? "p-0 d-flex align-items-center justify-content-center"
                      : "p-0"
                  }
                >
                  {isTripOver ? (
                    // --- NEW: COMPLETED VIEW ---
                    <div className="journey-completed-section">
                      <CheckCircleFill className="icon" />
                      <h4 className="mb-3">Journey Completed!</h4>
                      <p className="total-stat">
                        <strong>Total Distance:</strong>{" "}
                        {initialDistance.toFixed(2)} km
                        <br />
                        <strong>Arrival Time:</strong>{" "}
                        {new Date().toLocaleTimeString("en-US", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                      <Button
                        variant="primary"
                        size="lg"
                        className="w-100 btn-primary-custom"
                        onClick={() => navigate("/")}
                      >
                        Track Another Journey
                      </Button>
                    </div>
                  ) : (
                    // --- EXISTING: LOG VIEW ---
                    <ListGroup variant="flush" className="timesheet-list">
                      {liveTimeSheet.length > 0 ? (
                        liveTimeSheet.map((entry, index) => (
                          <ListGroup.Item key={index}>
                            <strong>{entry.time}:</strong> Reached{" "}
                            {entry.location.includes("Failed") ? (
                              <span className="text-danger fw-bold">
                                {entry.location}
                              </span>
                            ) : (
                              entry.location
                            )}
                          </ListGroup.Item>
                        ))
                      ) : (
                        <ListGroup.Item className="text-center text-muted p-5">
                          Journey log will appear here...
                        </ListGroup.Item>
                      )}
                    </ListGroup>
                  )}
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>

      {/* Toast Container remains the same */}
      <ToastContainer position="top-end" className="p-3">
        <Toast
          onClose={() => setShowToast(false)}
          show={showToast}
          delay={3000}
          autohide
        >
          <Toast.Header>
            <strong className="me-auto">Share</strong>
          </Toast.Header>
          <Toast.Body>Journey details copied to clipboard!</Toast.Body>
        </Toast>
      </ToastContainer>
    </Container>
  );
};

export default Tracking;
