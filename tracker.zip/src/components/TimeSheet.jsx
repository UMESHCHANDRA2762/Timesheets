import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Container,
  Card,
  Accordion,
  ListGroup,
  Badge,
  Row,
  Col,
  Button,
} from "react-bootstrap";

const TimeSheet = () => {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const savedHistory = JSON.parse(localStorage.getItem("rideHistory")) || [];
    setHistory(savedHistory.reverse()); // Show most recent first
  }, []);

  return (
    <Container className="p-4">
      <h1 className="mb-4">Journey History</h1>
      {history.length === 0 ? (
        <Card className="text-center p-4">
          <Card.Body>
            <Card.Title>No History Found</Card.Title>
            <Card.Text>
              You have no completed journeys. Track one to see it here.
            </Card.Text>
            <Button as={Link} to="/" variant="primary">
              Track a New Journey
            </Button>
          </Card.Body>
        </Card>
      ) : (
        <Accordion>
          {history.map((ride, index) => (
            <Accordion.Item eventKey={index.toString()} key={index}>
              <Accordion.Header>
                <div className="w-100 d-flex justify-content-between align-items-center pe-3">
                  <span className="fw-bold">ID: {ride.id}</span>
                  <span>
                    {ride.from} → {ride.to}
                  </span>
                  <Badge bg="secondary">{ride.date}</Badge>
                </div>
              </Accordion.Header>
              <Accordion.Body>
                <Row className="mb-3">
                  <Col>
                    <strong>Status:</strong>{" "}
                    <Badge bg="success">{ride.status}</Badge>
                  </Col>
                  <Col>
                    <strong>Duration:</strong> {ride.duration}
                  </Col>
                  <Col>
                    <strong>Distance:</strong> {ride.distance} km
                  </Col>
                </Row>

                {ride.timesheet && ride.timesheet.length > 0 && (
                  <div>
                    <h5 className="border-top pt-3">Journey Log:</h5>
                    <ListGroup variant="flush">
                      {ride.timesheet.map((entry, idx) => (
                        <ListGroup.Item
                          key={idx}
                          className="d-flex justify-content-between"
                        >
                          <span>
                            Reached <em>{entry.location}</em>
                          </span>
                          <strong>{entry.time}</strong>
                        </ListGroup.Item>
                      ))}
                    </ListGroup>
                  </div>
                )}
              </Accordion.Body>
            </Accordion.Item>
          ))}
        </Accordion>
      )}
      <div className="text-center mt-4">
        <Link to="/" className="text-primary">
          ← Back to Tracking Setup
        </Link>
      </div>
    </Container>
  );
};

export default TimeSheet;
