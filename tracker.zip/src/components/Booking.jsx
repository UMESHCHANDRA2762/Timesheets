import React, {
  useState,
  useEffect,
  useCallback,
  useRef,
  useMemo,
} from "react";
import { useNavigate } from "react-router-dom";
import {
  Container,
  Form,
  Card,
  Button,
  ListGroup,
  Spinner,
  InputGroup,
  Alert,
} from "react-bootstrap";
import {
  X,
  RecordCircleFill,
  CheckCircleFill,
  GeoAltFill,
} from "react-bootstrap-icons";
import "../styles/Booking.css";

const GEOAPIFY_API_KEY = "03a175bc0c42441180e543cad39c5749";
const GEOAPIFY_AUTOCOMPLETE_URL =
  "https://api.geoapify.com/v1/geocode/autocomplete";
const GEOAPIFY_REVERSE_URL = "https://api.geoapify.com/v1/geocode/reverse";
const DEBOUNCE_DELAY = 300;
const FETCH_TIMEOUT = 10000;

const calculateDistance = (coords1, coords2) => {
  if (!coords1 || !coords2) return 0;
  const toRad = (x) => (x * Math.PI) / 180;
  const R = 6371; // Earth radius in km
  const dLat = toRad(coords2.lat - coords1.lat);
  const dLon = toRad(coords2.lng - coords1.lng);
  const lat1 = toRad(coords1.lat);
  const lat2 = toRad(coords2.lat);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

const useLocationSearch = () => {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const abortControllerRef = useRef(null);

  const searchLocation = useCallback(async (searchQuery, signal) => {
    if (!searchQuery) {
      setResults([]);
      return;
    }
    setLoading(true);
    setError(null);
    const params = new URLSearchParams({
      text: searchQuery,
      apiKey: GEOAPIFY_API_KEY,
      filter: "countrycode:in",
      bias: `proximity:78.4867,17.3850`, // Hyderabad
    });
    try {
      const response = await fetch(
        `${GEOAPIFY_AUTOCOMPLETE_URL}?${params.toString()}`,
        { signal }
      );
      if (!response.ok) throw new Error("Network response was not ok");
      const data = await response.json();
      setResults(
        data.features?.map((f) => ({
          ...f.properties,
          display_name: f.properties.formatted,
        })) || []
      );
    } catch (err) {
      if (err.name !== "AbortError") setError("Could not fetch locations.");
    } finally {
      setLoading(false);
    }
  }, []);

  const triggerSearch = useCallback(
    (searchQuery) => {
      if (abortControllerRef.current) abortControllerRef.current.abort();
      const newController = new AbortController();
      abortControllerRef.current = newController;
      searchLocation(searchQuery, newController.signal);
    },
    [searchLocation]
  );

  const getCurrentLocation = useCallback(async () => {
    if (!navigator.geolocation) {
      setError("Geolocation is not supported by your browser.");
      throw new Error("Geolocation not supported.");
    }
    setLoading(true);
    setError(null);
    try {
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          timeout: FETCH_TIMEOUT,
        });
      });
      const { latitude, longitude } = position.coords;
      const url = `${GEOAPIFY_REVERSE_URL}?lat=${latitude}&lon=${longitude}&apiKey=${GEOAPIFY_API_KEY}`;
      const response = await fetch(url);
      const data = await response.json();
      if (data.features?.length > 0) {
        return {
          ...data.features[0].properties,
          display_name: data.features[0].properties.formatted,
        };
      } else {
        throw new Error("Could not determine address from coordinates.");
      }
    } catch (err) {
      setError(
        "Unable to retrieve your location. Please enable location services."
      );
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    query,
    setQuery,
    results,
    setResults,
    loading,
    error,
    triggerSearch,
    getCurrentLocation,
  };
};

const Booking = () => {
  const [activeInput, setActiveInput] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedPickup, setSelectedPickup] = useState(null);
  const [selectedDestination, setSelectedDestination] = useState(null);
  const pickupInputRef = useRef(null);
  const destinationInputRef = useRef(null);
  const navigate = useNavigate();
  const pickupSearch = useLocationSearch();
  const destinationSearch = useLocationSearch();

  useEffect(() => {
    if (
      activeInput === "pickup" &&
      pickupSearch.query &&
      pickupSearch.query !== selectedPickup?.name
    ) {
      const handler = setTimeout(
        () => pickupSearch.triggerSearch(pickupSearch.query),
        DEBOUNCE_DELAY
      );
      return () => clearTimeout(handler);
    }
  }, [pickupSearch.query, activeInput, selectedPickup, pickupSearch]);

  useEffect(() => {
    if (
      activeInput === "destination" &&
      destinationSearch.query &&
      destinationSearch.query !== selectedDestination?.name
    ) {
      const handler = setTimeout(
        () => destinationSearch.triggerSearch(destinationSearch.query),
        DEBOUNCE_DELAY
      );
      return () => clearTimeout(handler);
    }
  }, [
    destinationSearch.query,
    activeInput,
    selectedDestination,
    destinationSearch,
  ]);

  const journeyDetails = useMemo(() => {
    if (selectedPickup && selectedDestination) {
      const distance = calculateDistance(
        {
          lat: parseFloat(selectedPickup.lat),
          lng: parseFloat(selectedPickup.lon),
        },
        {
          lat: parseFloat(selectedDestination.lat),
          lng: parseFloat(selectedDestination.lon),
        }
      );
      return {
        distance: distance.toFixed(2),
        estimatedTime: Math.round(distance * 2.5),
      };
    }
    return null;
  }, [selectedPickup, selectedDestination]);

  // --- MODIFIED: This function contains the fix ---
  const handleSelectLocation = (location, type) => {
    const locationName = location.display_name.split(",")[0] || "Location";
    if (type === "pickup") {
      setSelectedPickup({ ...location, name: locationName });
      pickupSearch.setQuery(locationName);
      pickupSearch.setResults([]);
      setActiveInput("destination"); // Explicitly set the next active input
      destinationInputRef.current?.focus();
    } else {
      setSelectedDestination({ ...location, name: locationName });
      destinationSearch.setQuery(locationName);
      destinationSearch.setResults([]);
      // *** THE FIX: ***
      // By setting activeInput to null, we prevent the useEffect from
      // re-triggering a search after a selection is made.
      setActiveInput(null);
      destinationInputRef.current?.blur();
    }
  };

  const handleClearSearch = (type) => {
    if (type === "pickup") {
      pickupSearch.setQuery("");
      pickupSearch.setResults([]);
      setSelectedPickup(null);
      pickupInputRef.current?.focus();
    } else {
      destinationSearch.setQuery("");
      destinationSearch.setResults([]);
      setSelectedDestination(null);
      destinationInputRef.current?.focus();
    }
  };

  const handleGetCurrentLocationClick = async () => {
    try {
      const locData = await pickupSearch.getCurrentLocation();
      handleSelectLocation(locData, "pickup");
    } catch (err) {
      console.error("Failed to get current location in component:", err);
    }
  };

  const handleStartTracking = () => {
    if (!journeyDetails || !selectedPickup || !selectedDestination) return;
    setIsProcessing(true);
    const newJourney = {
      id: `J${Math.floor(1000 + Math.random() * 9000)}`,
      from: selectedPickup.name,
      to: selectedDestination.name,
      distance: journeyDetails.distance,
      userLocation: {
        lat: parseFloat(selectedDestination.lat),
        lng: parseFloat(selectedDestination.lon),
      },
      driverStartLocation: {
        lat: parseFloat(selectedPickup.lat),
        lng: parseFloat(selectedPickup.lon),
      },
    };

    setTimeout(() => {
      navigate(`/tracking/${newJourney.id}`, { state: { ride: newJourney } });
    }, 1500);
  };

  const renderResultsList = (search, type) => {
    if (!search.query || search.results.length === 0) return null;
    return (
      <ListGroup
        className="results-list position-absolute w-100"
        style={{ zIndex: 1000 }}
      >
        {search.results.map((loc) => (
          <ListGroup.Item
            action
            key={loc.place_id}
            onClick={() => handleSelectLocation(loc, type)}
          >
            <strong>{loc.display_name.split(",")[0]}</strong>
            <br />
            <small className="text-muted">
              {loc.display_name.split(",").slice(1).join(", ")}
            </small>
          </ListGroup.Item>
        ))}
      </ListGroup>
    );
  };

  return (
    <Container className="booking-container">
      <div className="booking-hero">
        <h1 className="hero-title">Track a New Journey</h1>
      </div>
      <Card className="booking-card">
        <Card.Body className="p-4">
          <div className="position-relative">
            <div className="route-connector"></div>
            <div className="d-flex align-items-center mb-4">
              {selectedPickup ? (
                <CheckCircleFill
                  size={20}
                  className="text-success flex-shrink-0"
                />
              ) : (
                <RecordCircleFill
                  size={20}
                  className="text-primary flex-shrink-0"
                />
              )}
              <div className="ms-3 w-100 position-relative">
                <InputGroup>
                  <Form.Control
                    ref={pickupInputRef}
                    type="text"
                    placeholder="Enter Start Location"
                    value={pickupSearch.query}
                    onChange={(e) => {
                      pickupSearch.setQuery(e.target.value);
                      setSelectedPickup(null);
                    }}
                    onFocus={() => setActiveInput("pickup")}
                    autoComplete="off"
                    disabled={isProcessing}
                  />
                  {pickupSearch.query && (
                    <Button
                      variant="light"
                      onClick={() => handleClearSearch("pickup")}
                      className="d-flex align-items-center"
                    >
                      <X size={20} />
                    </Button>
                  )}
                  <Button
                    variant="light"
                    onClick={handleGetCurrentLocationClick}
                    disabled={pickupSearch.loading}
                    className="d-flex align-items-center"
                  >
                    {pickupSearch.loading && activeInput === "pickup" ? (
                      <Spinner size="sm" />
                    ) : (
                      <GeoAltFill />
                    )}
                  </Button>
                </InputGroup>
                {activeInput === "pickup" &&
                  renderResultsList(pickupSearch, "pickup")}
              </div>
            </div>
            <div className="d-flex align-items-center">
              {selectedDestination ? (
                <CheckCircleFill
                  size={20}
                  className="text-success flex-shrink-0"
                />
              ) : (
                <RecordCircleFill
                  size={20}
                  className="text-danger flex-shrink-0"
                />
              )}
              <div className="ms-3 w-100 position-relative">
                <InputGroup>
                  <Form.Control
                    ref={destinationInputRef}
                    type="text"
                    placeholder="Enter Destination"
                    value={destinationSearch.query}
                    onChange={(e) => {
                      destinationSearch.setQuery(e.target.value);
                      setSelectedDestination(null);
                    }}
                    onFocus={() => setActiveInput("destination")}
                    autoComplete="off"
                    disabled={isProcessing}
                  />
                  {destinationSearch.query && (
                    <Button
                      variant="light"
                      onClick={() => handleClearSearch("destination")}
                      className="d-flex align-items-center"
                    >
                      <X size={20} />
                    </Button>
                  )}
                  {destinationSearch.loading &&
                    activeInput === "destination" && (
                      <InputGroup.Text>
                        <Spinner animation="border" size="sm" />
                      </InputGroup.Text>
                    )}
                </InputGroup>
                {activeInput === "destination" &&
                  renderResultsList(destinationSearch, "destination")}
              </div>
            </div>
          </div>
          {pickupSearch.error && activeInput === "pickup" && (
            <Alert variant="danger" className="mt-3 small">
              {pickupSearch.error}
            </Alert>
          )}
          {destinationSearch.error && activeInput === "destination" && (
            <Alert variant="danger" className="mt-3 small">
              {destinationSearch.error}
            </Alert>
          )}
          {journeyDetails && (
            <Card className="estimate-card mt-4">
              <Card.Body className="text-center">
                <div className="d-flex justify-content-around align-items-center">
                  <div>
                    <div className="h5 fw-bold">
                      {journeyDetails.distance} km
                    </div>
                    <div className="small text-muted">Distance</div>
                  </div>
                  <div>
                    <div className="h5 fw-bold">
                      {journeyDetails.estimatedTime} min
                    </div>
                    <div className="small text-muted">Est. Time</div>
                  </div>
                </div>
                {isProcessing ? (
                  <div className="d-flex justify-content-center align-items-center mt-3">
                    <Spinner size="sm" className="me-2" />{" "}
                    <span className="fw-bold">Initializing...</span>
                  </div>
                ) : (
                  <Button
                    variant="primary"
                    size="lg"
                    className="w-100 mt-3 book-ride-btn"
                    onClick={handleStartTracking}
                  >
                    Start Tracking
                  </Button>
                )}
              </Card.Body>
            </Card>
          )}
        </Card.Body>
      </Card>
    </Container>
  );
};

export default Booking;
