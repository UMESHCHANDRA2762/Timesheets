import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./utils/leafletIconFix";

import Booking from "./components/Booking";
import Tracking from "./components/Tracking";

const AppNavbar = () => (
  <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
    <div className="container-fluid">
      <Link className="navbar-brand" to="/">
        Location Tracking
      </Link>
    </div>
  </nav>
);

function App() {
  return (
    <Router basename="/Timesheets">
      <AppNavbar />
      <div className="App">
        <Routes>
          <Route path="/" element={<Booking />} />
          <Route path="tracking/:rideId" element={<Tracking />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
